<?php
namespace Elementor\Core\Isolation;

interface Kit_Adapter_Interface {

	public function get_kit_settings();

	public function get_main_post();
}
