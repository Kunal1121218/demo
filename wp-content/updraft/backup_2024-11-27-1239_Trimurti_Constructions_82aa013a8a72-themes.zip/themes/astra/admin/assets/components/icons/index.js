import Star from "./Star";

export { Star };
